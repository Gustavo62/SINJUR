(function() {
  jQuery(function() {
    return $('#atividade_data').datepicker();
  });

}).call(this);
